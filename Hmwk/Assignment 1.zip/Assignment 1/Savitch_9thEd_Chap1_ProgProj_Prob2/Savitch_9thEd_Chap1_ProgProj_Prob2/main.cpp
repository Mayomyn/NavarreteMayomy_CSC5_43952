/* 
 * File:   main.cpp
 * Author: Mayomy Navarrete
 * Created on March 6, 2015, 4:30 PM
 *      //Purpose calculate the number of hours someone work per week 
 */

#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    cout<<"**************************************************\n";
    cout<<"\n";
    cout<<"          C C C          S S S S          !!\n";
    cout<<"        C        C     S         S        !!\n";
    cout<<"       C              S                   !!\n";
    cout<<"      C                S                  !!\n";
    cout<<"      C                 S S S S           !!\n";
    cout<<"      C                          S        !!\n";
    cout<<"       C                          S       !!\n";
    cout<<"        C        C     S         S          \n";
    cout<<"          C C C          S S S S          00\n";
    cout<<"\n";
    cout<<"**************************************************\n";
    cout<<"       Computer Science is Cool Stuff!!!";
    return 0;
}

