/* 
 * File:   main.cpp
 * Author: Mayomy Navarrete
 * Created on March 6, 2015, 4:30 PM
 *      //Purpose calculate the number of hours someone work per week 
 */

#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    cout<<"Please enter any one character on the keyboard.\n";
    char input;
    cin >> input;
    cout <<"  " << input << " " << input << " " << input << "\n";
    cout <<" " << input << "    " << input << "\n";
    cout << input << "\n";
    cout << input << "\n";
    cout << input << "\n";
    cout << input << "\n";
    cout << input << "\n";
    cout <<" " << input << "    " << input << "\n";
    cout <<"  " << input << " " << input << " " << input << "\n";
    return 0;
}

